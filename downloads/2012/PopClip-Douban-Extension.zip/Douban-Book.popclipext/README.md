Search selected text on douban

- Cantact me

* soundbbg@gmail.com
* http://guojing.me