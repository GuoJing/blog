# -*- coding: utf-8 -*-

STATION_IP = ''
DEVICE_TYPE = ''
DEFAULT_TRANSITIONTIME = 3

try:
    from local_config import *
except:
    pass
