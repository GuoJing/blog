pyhue
=====

This is a simple python sdk for philips hue (personal lightting system).

How to use
=====

This should be very easy.

Prepare
------

1. git clone the code
2. cp config.py to local_config.py
3. from pyhue.nupnp import get_hue
4. hue = get_hue()

Auth
-----
You also can get hue like this:

This will load the config file

    from pyhue import hue
    hue = Hue()

or

    hue = Hue(ip, devicetype)

Then run (only the first time)

    hue = auth()

__get to your hue and press the BUTTON__

and Done

Usage
-----

next time you just can do like the main.py

    lights = hue.lights
    light = lights[0]
    light.on()
    light.off()
    light.set_state()

can you also could use hue object

    hue.create_schedule()
    hue.get_new_lights()

Next
-----

main.py have some simple samples.

Chinese
-----

1. 下载代码
2. 拷贝config.py到local_config.py
3. 去 [www.meethue.com/api/nupnp](http://www.meethue.com/api/nupnp) 页面获取信息
4. 修改local_config.py
5. 使用代码，h=Hue()
6. h.auth()并且按Hue的中间的按钮
7. 认证完毕
8. 查看main.py的一些例子

Contact
-----
soundbbg at gmail
